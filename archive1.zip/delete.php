<?php

unlink($_POST['file']);


?>